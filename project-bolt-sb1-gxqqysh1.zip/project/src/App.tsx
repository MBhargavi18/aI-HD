import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './components/ui/card';
import { Button } from './components/ui/button';
import { Input } from './components/ui/input';
import { Label } from './components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './components/ui/select';
import { Slider } from './components/ui/slider';
import { Brain, Upload, AlertTriangle, CheckCircle, Activity, ThermometerSnowflake as ThermometerSnow } from 'lucide-react';

function App() {
  // Skin disease states
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [skinResult, setSkinResult] = useState<any>(null);

  // Pregnancy risk states
  const [patientData, setPatientData] = useState({
    age: 30,
    systolicBP: 120,
    diastolicBP: 80,
    bloodGlucose: 6.0,
    bodyTemp: 37.0,
    heartRate: 75
  });
  const [isCalculating, setIsCalculating] = useState(false);
  const [pregnancyResult, setPregnancyResult] = useState<any>(null);

  // Handle image upload
  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const reader = new FileReader();
      reader.onload = (e) => {
        if (e.target?.result) {
          setSelectedImage(e.target.result as string);
        }
      };
      reader.readAsDataURL(e.target.files[0]);
    }
  };

  // Simulate skin disease analysis
  const analyzeSkin = () => {
    setIsAnalyzing(true);
    // Simulate API call delay
    setTimeout(() => {
      const diseases = ['Melanoma', 'Eczema', 'Psoriasis', 'Normal'];
      const severities = ['Mild', 'Moderate', 'Severe'];
      
      // Randomly select a disease and severity for demo purposes
      const diseaseIndex = Math.floor(Math.random() * diseases.length);
      const disease = diseases[diseaseIndex];
      
      // Only assign severity if not normal
      let severity = null;
      let recommendations = [];
      
      if (disease !== 'Normal') {
        const severityIndex = Math.floor(Math.random() * severities.length);
        severity = severities[severityIndex];
        
        // Generate recommendations based on disease and severity
        if (disease === 'Melanoma') {
          if (severity === 'Mild') {
            recommendations = [
              "Schedule an appointment with a dermatologist within 1-2 weeks",
              "Avoid sun exposure to the affected area",
              "Take photographs to monitor any changes"
            ];
          } else if (severity === 'Moderate') {
            recommendations = [
              "See a dermatologist urgently (within days)",
              "Prepare for possible biopsy procedure",
              "Avoid sun exposure completely"
            ];
          } else {
            recommendations = [
              "Seek immediate medical attention",
              "This requires urgent specialist assessment",
              "Prepare for possible surgical intervention"
            ];
          }
        } else if (disease === 'Eczema') {
          if (severity === 'Mild') {
            recommendations = [
              "Use over-the-counter moisturizers regularly",
              "Avoid known triggers (certain soaps, detergents, etc.)",
              "Take short, lukewarm showers instead of hot baths"
            ];
          } else if (severity === 'Moderate') {
            recommendations = [
              "Consult with a dermatologist for prescription treatments",
              "Consider topical corticosteroids",
              "Keep the affected area clean and moisturized"
            ];
          } else {
            recommendations = [
              "Seek dermatologist care promptly",
              "May require prescription-strength medications or phototherapy",
              "Watch for signs of infection (increased pain, pus, etc.)"
            ];
          }
        } else if (disease === 'Psoriasis') {
          if (severity === 'Mild') {
            recommendations = [
              "Use over-the-counter salicylic acid products",
              "Apply moisturizer regularly",
              "Get moderate sun exposure (10-15 minutes daily)"
            ];
          } else if (severity === 'Moderate') {
            recommendations = [
              "Consult with a dermatologist for prescription treatments",
              "Consider topical treatments containing corticosteroids or vitamin D",
              "Avoid triggers like stress, alcohol, and smoking"
            ];
          } else {
            recommendations = [
              "See a dermatologist for advanced treatment options",
              "May require systemic medications or biologics",
              "Consider phototherapy under medical supervision"
            ];
          }
        }
      } else {
        recommendations = [
          "Continue with regular skin care routine",
          "Protect your skin from sun exposure",
          "Perform regular self-examinations"
        ];
      }
      
      // Create result object
      const result = {
        disease,
        severity,
        confidence: (75 + Math.random() * 20).toFixed(1) + '%',
        description: getDescription(disease),
        recommendations
      };
      
      setSkinResult(result);
      setIsAnalyzing(false);
    }, 2000);
  };

  // Get description for skin disease
  const getDescription = (disease: string) => {
    const descriptions: {[key: string]: string} = {
      'Melanoma': "Melanoma is a serious form of skin cancer that begins in cells known as melanocytes. While it is less common than other types of skin cancer, it causes the majority of skin cancer deaths.",
      'Eczema': "Eczema (atopic dermatitis) is a condition that causes your skin to become dry, itchy, red and cracked. It is common in children but can occur at any age.",
      'Psoriasis': "Psoriasis is a skin disorder that causes skin cells to multiply up to 10 times faster than normal. This makes the skin build up into bumpy red patches covered with white scales.",
      'Normal': "No concerning skin condition detected. Your skin appears healthy based on the provided image."
    };
    
    return descriptions[disease] || "No description available.";
  };

  // Handle patient data change
  const handlePatientDataChange = (field: string, value: number) => {
    setPatientData({
      ...patientData,
      [field]: value
    });
  };

  // Simulate pregnancy risk calculation
  const calculatePregnancyRisk = () => {
    setIsCalculating(true);
    // Simulate API call delay
    setTimeout(() => {
      // Risk calculation logic (simplified for demo)
      let riskLevel = 'low risk';
      let riskScore = 0;
      
      // Check blood pressure
      if (patientData.systolicBP > 140 || patientData.diastolicBP > 90) {
        riskScore += 2;
      } else if (patientData.systolicBP > 130 || patientData.diastolicBP > 85) {
        riskScore += 1;
      }
      
      // Check blood glucose
      if (patientData.bloodGlucose > 8.0) {
        riskScore += 2;
      } else if (patientData.bloodGlucose > 7.0) {
        riskScore += 1;
      }
      
      // Check body temperature
      if (patientData.bodyTemp > 38.0) {
        riskScore += 1;
      }
      
      // Check heart rate
      if (patientData.heartRate > 100) {
        riskScore += 1;
      } else if (patientData.heartRate > 90) {
        riskScore += 0.5;
      }
      
      // Check age
      if (patientData.age > 35) {
        riskScore += 1;
      }
      
      // Determine risk level
      if (riskScore >= 3) {
        riskLevel = 'high risk';
      } else if (riskScore >= 1.5) {
        riskLevel = 'mid risk';
      }
      
      // Generate recommendations
      const baseRecommendations = [
        "Maintain a balanced diet rich in fruits, vegetables, and whole grains",
        "Stay hydrated by drinking plenty of water throughout the day",
        "Get regular moderate exercise as approved by your healthcare provider"
      ];
      
      let specificRecommendations = [];
      let followUp = "";
      
      if (riskLevel === 'low risk') {
        specificRecommendations = [
          "Continue with routine prenatal check-ups",
          "Monitor fetal movements daily",
          "Take prenatal vitamins as prescribed"
        ];
        followUp = "Schedule your next routine prenatal visit in 4 weeks.";
      } else if (riskLevel === 'mid risk') {
        specificRecommendations = [
          "Increase frequency of prenatal visits as advised by your doctor",
          "Monitor blood pressure regularly at home if possible",
          "Limit sodium intake and avoid processed foods",
          "Be vigilant about reporting any new symptoms to your healthcare provider"
        ];
        followUp = "Schedule a follow-up appointment within 1-2 weeks to reassess your condition.";
      } else {
        specificRecommendations = [
          "Urgent consultation with an obstetrician is recommended",
          "Strict monitoring of blood pressure and other vital signs",
          "Consider hospital evaluation if experiencing severe headaches, vision changes, or upper abdominal pain",
          "Prepare for possible early delivery or additional interventions",
          "Reduce physical activity and consider bed rest as advised by your doctor"
        ];
        followUp = "Immediate follow-up with a maternal-fetal medicine specialist is recommended within the next 24-48 hours.";
      }
      
      // Create result object
      const result = {
        riskLevel: riskLevel.toUpperCase(),
        confidence: (75 + Math.random() * 20).toFixed(1) + '%',
        patientSummary: {
          'Age': patientData.age,
          'Blood Pressure': `${patientData.systolicBP}/${patientData.diastolicBP} mmHg`,
          'Blood Glucose': `${patientData.bloodGlucose} mmol/L`,
          'Body Temperature': `${patientData.bodyTemp} °C`,
          'Heart Rate': `${patientData.heartRate} bpm`
        },
        recommendations: [...baseRecommendations, ...specificRecommendations],
        followUp
      };
      
      setPregnancyResult(result);
      setIsCalculating(false);
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gray-50 p-4 md:p-8">
      <header className="max-w-6xl mx-auto mb-8">
        <div className="flex items-center gap-2 mb-2">
          <Brain className="h-8 w-8 text-indigo-600" />
          <h1 className="text-2xl md:text-3xl font-bold text-gray-900">AI Health Diagnostic Platform</h1>
        </div>
        <p className="text-gray-600">Advanced diagnostics for skin diseases and pregnancy risk assessment</p>
      </header>

      <main className="max-w-6xl mx-auto">
        <Tabs defaultValue="skin" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-8">
            <TabsTrigger value="skin">Skin Disease Screening</TabsTrigger>
            <TabsTrigger value="pregnancy">Pregnancy Risk Assessment</TabsTrigger>
          </TabsList>

          {/* Skin Disease Screening Tab */}
          <TabsContent value="skin">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Upload Skin Image</CardTitle>
                  <CardDescription>
                    Upload a clear image of the affected skin area for analysis
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex flex-col items-center justify-center border-2 border-dashed border-gray-300 rounded-lg p-6 bg-gray-50">
                      {selectedImage ? (
                        <div className="w-full">
                          <img 
                            src={selectedImage} 
                            alt="Selected skin" 
                            className="max-h-64 mx-auto rounded-lg object-contain"
                          />
                          <Button 
                            variant="outline" 
                            className="mt-4 w-full"
                            onClick={() => setSelectedImage(null)}
                          >
                            Remove Image
                          </Button>
                        </div>
                      ) : (
                        <div className="text-center">
                          <Upload className="h-12 w-12 text-gray-400 mx-auto mb-2" />
                          <p className="text-sm text-gray-500 mb-4">
                            Drag and drop an image, or click to browse
                          </p>
                          <Label htmlFor="image-upload" className="cursor-pointer">
                            <Input 
                              id="image-upload" 
                              type="file" 
                              accept="image/*" 
                              className="hidden"
                              onChange={handleImageChange}
                            />
                            <Button variant="outline">Select Image</Button>
                          </Label>
                        </div>
                      )}
                    </div>
                    <Button 
                      className="w-full" 
                      disabled={!selectedImage || isAnalyzing}
                      onClick={analyzeSkin}
                    >
                      {isAnalyzing ? 'Analyzing...' : 'Analyze Skin Condition'}
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Analysis Results</CardTitle>
                  <CardDescription>
                    Diagnostic information and recommendations
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {skinResult ? (
                    <div className="space-y-4">
                      <div className="flex items-center gap-2">
                        <div className={`p-2 rounded-full ${
                          skinResult.disease === 'Normal' 
                            ? 'bg-green-100' 
                            : skinResult.severity === 'Mild' 
                              ? 'bg-yellow-100' 
                              : skinResult.severity === 'Moderate' 
                                ? 'bg-orange-100' 
                                : 'bg-red-100'
                        }`}>
                          {skinResult.disease === 'Normal' ? (
                            <CheckCircle className={`h-6 w-6 text-green-600`} />
                          ) : (
                            <AlertTriangle className={`h-6 w-6 ${
                              skinResult.severity === 'Mild' 
                                ? 'text-yellow-600' 
                                : skinResult.severity === 'Moderate' 
                                  ? 'text-orange-600' 
                                  : 'text-red-600'
                            }`} />
                          )}
                        </div>
                        <div>
                          <h3 className="font-semibold text-lg">{skinResult.disease}</h3>
                          {skinResult.severity && (
                            <p className="text-sm text-gray-500">Severity: {skinResult.severity}</p>
                          )}
                        </div>
                        <div className="ml-auto">
                          <span className="bg-indigo-100 text-indigo-800 text-xs font-medium px-2.5 py-0.5 rounded">
                            Confidence: {skinResult.confidence}
                          </span>
                        </div>
                      </div>

                      <div>
                        <h4 className="font-medium text-sm text-gray-500 mb-1">Description</h4>
                        <p className="text-sm">{skinResult.description}</p>
                      </div>

                      <div>
                        <h4 className="font-medium text-sm text-gray-500 mb-1">Recommendations</h4>
                        <ul className="list-disc pl-5 text-sm space-y-1">
                          {skinResult.recommendations.map((rec: string, i: number) => (
                            <li key={i}>{rec}</li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      <p>Upload and analyze an image to see results</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Pregnancy Risk Assessment Tab */}
          <TabsContent value="pregnancy">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Patient Information</CardTitle>
                  <CardDescription>
                    Enter patient data for pregnancy risk assessment
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <Label htmlFor="age">Age (years)</Label>
                        <span className="text-sm text-gray-500">{patientData.age}</span>
                      </div>
                      <Slider 
                        id="age"
                        min={18} 
                        max={45} 
                        step={1}
                        value={[patientData.age]}
                        onValueChange={(value) => handlePatientDataChange('age', value[0])}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="systolicBP">Systolic BP (mmHg)</Label>
                        <Input 
                          id="systolicBP"
                          type="number" 
                          value={patientData.systolicBP}
                          onChange={(e) => handlePatientDataChange('systolicBP', parseInt(e.target.value))}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="diastolicBP">Diastolic BP (mmHg)</Label>
                        <Input 
                          id="diastolicBP"
                          type="number" 
                          value={patientData.diastolicBP}
                          onChange={(e) => handlePatientDataChange('diastolicBP', parseInt(e.target.value))}
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <Label htmlFor="bloodGlucose">Blood Glucose (mmol/L)</Label>
                        <span className="text-sm text-gray-500">{patientData.bloodGlucose}</span>
                      </div>
                      <Slider 
                        id="bloodGlucose"
                        min={4.0} 
                        max={11.0} 
                        step={0.1}
                        value={[patientData.bloodGlucose]}
                        onValueChange={(value) => handlePatientDataChange('bloodGlucose', value[0])}
                      />
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <Label htmlFor="bodyTemp">Body Temperature (°C)</Label>
                        <span className="text-sm text-gray-500">{patientData.bodyTemp}</span>
                      </div>
                      <Slider 
                        id="bodyTemp"
                        min={36.0} 
                        max={39.0} 
                        step={0.1}
                        value={[patientData.bodyTemp]}
                        onValueChange={(value) => handlePatientDataChange('bodyTemp', value[0])}
                      />
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <Label htmlFor="heartRate">Heart Rate (bpm)</Label>
                        <span className="text-sm text-gray-500">{patientData.heartRate}</span>
                      </div>
                      <Slider 
                        id="heartRate"
                        min={60} 
                        max={120} 
                        step={1}
                        value={[patientData.heartRate]}
                        onValueChange={(value) => handlePatientDataChange('heartRate', value[0])}
                      />
                    </div>

                    <Button 
                      className="w-full" 
                      disabled={isCalculating}
                      onClick={calculatePregnancyRisk}
                    >
                      {isCalculating ? 'Calculating...' : 'Calculate Risk'}
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Risk Assessment</CardTitle>
                  <CardDescription>
                    Pregnancy risk evaluation and recommendations
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {pregnancyResult ? (
                    <div className="space-y-4">
                      <div className="flex items-center gap-2">
                        <div className={`p-2 rounded-full ${
                          pregnancyResult.riskLevel === 'LOW RISK' 
                            ? 'bg-green-100' 
                            : pregnancyResult.riskLevel === 'MID RISK' 
                              ? 'bg-yellow-100' 
                              : 'bg-red-100'
                        }`}>
                          {pregnancyResult.riskLevel === 'LOW RISK' ? (
                            <CheckCircle className="h-6 w-6 text-green-600" />
                          ) : pregnancyResult.riskLevel === 'MID RISK' ? (
                            <AlertTriangle className="h-6 w-6 text-yellow-600" />
                          ) : (
                            <AlertTriangle className="h-6 w-6 text-red-600" />
                          )}
                        </div>
                        <div>
                          <h3 className="font-semibold text-lg">{pregnancyResult.riskLevel}</h3>
                        </div>
                        <div className="ml-auto">
                          <span className="bg-indigo-100 text-indigo-800 text-xs font-medium px-2.5 py-0.5 rounded">
                            Confidence: {pregnancyResult.confidence}
                          </span>
                        </div>
                      </div>

                      <div>
                        <h4 className="font-medium text-sm text-gray-500 mb-1">Patient Summary</h4>
                        <div className="grid grid-cols-2 gap-2 text-sm">
                          {Object.entries(pregnancyResult.patientSummary).map(([key, value]) => (
                            <div key={key} className="flex justify-between">
                              <span className="text-gray-600">{key}:</span>
                              <span className="font-medium">{value}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div>
                        <h4 className="font-medium text-sm text-gray-500 mb-1">Recommendations</h4>
                        <ul className="list-disc pl-5 text-sm space-y-1">
                          {pregnancyResult.recommendations.map((rec: string, i: number) => (
                            <li key={i}>{rec}</li>
                          ))}
                        </ul>
                      </div>

                      <div className="bg-blue-50 p-3 rounded-md">
                        <h4 className="font-medium text-sm text-blue-800 mb-1">Follow-up</h4>
                        <p className="text-sm text-blue-700">{pregnancyResult.followUp}</p>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      <p>Enter patient data and calculate risk to see results</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </main>

      <footer className="max-w-6xl mx-auto mt-12 pt-6 border-t border-gray-200 text-center text-gray-500 text-sm">
        <p>AI Health Diagnostic Platform - For demonstration purposes only</p>
        <p className="mt-1">This system is intended to assist healthcare professionals and should not replace professional medical advice.</p>
      </footer>
    </div>
  );
}

export default App;